# =============================================================
#              💻 PYTHON ASSIGNMENT: DIGIT OPERATIONS
# =============================================================
# This program implements three fundamental number operations:
#   1️⃣ COUNT_DIGITS(n)   → Counts total digits in an integer
#   2️⃣ SUM_DIGITS(n)     → Calculates the sum of digits
#   3️⃣ REVERSE_NUMBER(n) → Reverses the digits of a number
#
# Each section includes:
#   - Pseudocode (algorithm steps)
#   - Well-commented Python implementation
#   - Test cases (Input → Expected → Actual)
#   - A short correctness explanation
#
# Author : [Your Name]
# Date   : [Submission Date]
# =============================================================


# =============================================================
# 1️⃣ COUNT_DIGITS(n)
# =============================================================

"""
------------------ PSEUDOCODE ------------------
FUNCTION COUNT_DIGITS(n):
    SET n = absolute value of n
    IF n == 0:
        RETURN 1
    SET count = 0
    WHILE n > 0:
        n = n // 10
        count = count + 1
    RETURN count
-----------------------------------------------
"""

def COUNT_DIGITS(n):
    """Counts number of digits in an integer."""
    n = abs(n)  # handle negative numbers
    if n == 0:
        return 1  # zero has one digit
    count = 0
    while n > 0:
        n //= 10   # remove last digit
        count += 1
    return count


# ------------------ TEST CASES ------------------
print("🔹 Testing COUNT_DIGITS Function")
print("Input: 12345 → Expected: 5 → Actual:", COUNT_DIGITS(12345))
print("Input: -908  → Expected: 3 → Actual:", COUNT_DIGITS(-908))
print("Input: 0     → Expected: 1 → Actual:", COUNT_DIGITS(0))
# ------------------------------------------------

# ✅ Correctness Explanation:
# The loop divides the number by 10 each time, removing one digit per step.
# abs() ensures that negative numbers are handled correctly.
print("=" * 60)


# =============================================================
# 2️⃣ SUM_DIGITS(n)
# =============================================================

"""
------------------ PSEUDOCODE ------------------
FUNCTION SUM_DIGITS(n):
    SET n = absolute value of n
    SET total = 0
    WHILE n > 0:
        digit = n % 10
        total = total + digit
        n = n // 10
    RETURN total
-----------------------------------------------
"""

def SUM_DIGITS(n):
    """Finds the sum of all digits in an integer."""
    n = abs(n)  # handle negative numbers
    total = 0
    if n == 0:
        return 0
    while n > 0:
        digit = n % 10     # extract last digit
        total += digit
        n //= 10           # remove last digit
    return total


# ------------------ TEST CASES ------------------
print("🔹 Testing SUM_DIGITS Function")
print("Input: 1234 → Expected: 10 → Actual:", SUM_DIGITS(1234))
print("Input: -507 → Expected: 12 → Actual:", SUM_DIGITS(-507))
print("Input: 0    → Expected: 0  → Actual:", SUM_DIGITS(0))
# ------------------------------------------------

# ✅ Correctness Explanation:
# Each iteration extracts the last digit using % 10 and adds it to total.
# Using abs() ensures it works for negative numbers as well.
print("=" * 60)


# =============================================================
# 3️⃣ REVERSE_NUMBER(n)
# =============================================================

"""
------------------ PSEUDOCODE ------------------
FUNCTION REVERSE_NUMBER(n):
    SET sign = 1
    IF n < 0:
        SET sign = -1
    SET n = absolute value of n
    SET rev = 0
    WHILE n > 0:
        digit = n % 10
        rev = rev * 10 + digit
        n = n // 10
    RETURN sign * rev
-----------------------------------------------
"""

def REVERSE_NUMBER(n):
    """Reverses the digits of an integer while preserving sign."""
    sign = -1 if n < 0 else 1  # store sign
    n = abs(n)
    rev = 0
    while n > 0:
        digit = n % 10          # extract last digit
        rev = rev * 10 + digit  # append to reversed number
        n //= 10
    return sign * rev           # apply sign back


# ------------------ TEST CASES ------------------
print("🔹 Testing REVERSE_NUMBER Function")
print("Input: 1234 → Expected: 4321 → Actual:", REVERSE_NUMBER(1234))
print("Input: -560 → Expected: -65  → Actual:", REVERSE_NUMBER(-560))
print("Input: 0    → Expected: 0    → Actual:", REVERSE_NUMBER(0))
# ------------------------------------------------

# ✅ Correctness Explanation:
# The digits are reversed mathematically using integer arithmetic.
# The sign is reapplied at the end to handle negative numbers.
print("=" * 60)


# =============================================================
# ✅ END OF ASSIGNMENT
# =============================================================
