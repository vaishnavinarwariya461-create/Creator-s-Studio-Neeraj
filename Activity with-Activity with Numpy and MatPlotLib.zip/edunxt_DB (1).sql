
USE edunext;
-- Drop existing tables if they exist
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS courses;

-- Create students table
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(100),
    city VARCHAR(50)
);

-- Create courses table
CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_title VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(8,2)
);

-- Create enrollments table (junction table)
CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

-- Insert sample students
INSERT INTO students (student_name, city) VALUES 
('Rahul Sharma', 'Mumbai'),
('Priya Mehta', 'Bangalore'),
('Neha Gupta', 'Chennai');

-- Insert sample courses
INSERT INTO courses (course_title, category, price) VALUES 
('Python for Beginners', 'Programming', 999),
('Intro to HTML4', 'Web Development', 799),
('Machine Learning Basics', 'Data Science', 1999),
('Statistics with R', 'Data Science', 1800),
('Data Visualization with Power BI', 'Data Science', 2500),
('Advanced Java', 'Programming', 2200);

-- Insert sample enrollments
INSERT INTO enrollments (student_id, course_id) VALUES
(1, 1), -- Rahul -> Python
(1, 3), -- Rahul -> ML Basics
(2, 4), -- Priya -> Statistics with R
(3, 2); -- Neha -> HTML4

SELECT * 
FROM courses 
WHERE category = 'Data Science';


INSERT INTO students (student_name, city) VALUES 
('Arjun Verma' , 'Delhi');
SELECT * FROM students;


UPDATE course
SET price = 1499
WHERE course_title = 'Python for Beginners';

DELETE FROM courses
WHERE course_title = 'Intro to HTML4';


SELECT * FROM students;
SELECT * FROM courses;
SELECT * FROM enrollments;

SELECT * FROM courses WHERE category = 'Data Science';

SELECT * FROM students;
SELECT * FROM courses WHERE course_title = 'Python for Beginners';
UPDATE courses 
SET price = 1499 
WHERE course_title = 'Python for Beginners';
SET SQL_SAFE_UPDATES = 0;

UPDATE courses 
SET price = 1499 
WHERE course_title = 'Python for Beginners';
SET SQL_SAFE_UPDATES = 1;

 
 



 




